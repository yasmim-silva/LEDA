package adt.avltree;

import adt.bst.BST;

public interface AVLTree<T extends Comparable<T>> extends BST<T> {

}
